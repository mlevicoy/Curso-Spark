# Big Data y Spark: ingeniería de datos con Python y pyspark
 
 En este [curso](https://www.udemy.com/course/big-data-y-spark-ingenieria-de-datos-con-python-y-pyspark/?referralCode=F123CAABFC966F4483EC) aprenderás a trabajar con Spark a través de la librería PySpark de Python en Google Colaboratory.

 El repositorio está dividido por secciones y dentro de cada sección encontrará los archivos `.py` correspondientes a la lección asociada. Estos mismos archivos estarán disponibles como recursos descargables en cada lección del curso.
